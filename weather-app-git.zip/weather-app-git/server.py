from flask import Flask, render_template, request
from weather import get_current_weather
from waitress import serve

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/weather')
def get_weather():
    zipcode = request.args.get('zipcode')
    country_code = request.args.get('country_code')
    weather_data, city, alert_headline = get_current_weather(zipcode, country_code)
    return render_template(
        "weather.html",
        status=weather_data['current']['weather'][0]['description'],
        temp=weather_data["current"]["temp"],
        feels_like=weather_data["current"]["feels_like"],
        location=city,
        today=weather_data['daily'][1]['temp']['day'],
        tomorrow=weather_data['daily'][2]['temp']['day'],
        two_days_future=weather_data['daily'][3]['temp']['day'],
        three_days_future=weather_data['daily'][4]['temp']['day'],
        four_days_future=weather_data['daily'][5]['temp']['day'],
        five_days_future=weather_data['daily'][6]['temp']['day'],
        six_days_future=weather_data['daily'][7]['temp']['day'],
        one_hour=weather_data['hourly'][1]['temp'],
        two_hours=weather_data['hourly'][2]['temp'],
        three_hours=weather_data['hourly'][3]['temp'],
        four_hours=weather_data['hourly'][4]['temp'],
        five_hours=weather_data['hourly'][5]['temp'],
        six_hours=weather_data['hourly'][6]['temp'],
        seven_hours=weather_data['hourly'][7]['temp'],
        alert=alert_headline
    )
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)