from flask import Flask, render_template, request
from waitress import serve
from datetime import date, timedelta, datetime
import calendar
import json

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/weather', methods=['POST', 'GET'])
def get_weather():
    if request.method=='POST':
        
 
        return render_template(
            "weather.html",
        )
        
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)