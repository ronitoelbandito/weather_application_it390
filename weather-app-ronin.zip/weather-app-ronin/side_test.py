'''preferences = []
x = True
while x is True:
    user_input = input("Which preferences would you like to use? ")
    if user_input == "n":
        x = False
    else:
        preferences.append(user_input)
        print(preferences)

pref_dict = {'UV':'uvi', 'Wind Speed':'wind_speed'}
chosen_preferences = []
for x in preferences:
    if x in pref_dict.keys():
        chosen_preferences.append(x)

print(chosen_preferences)

preferences = []

  current_weather = weather_data['current']['weather']

  for pref in user_preferences:
     if pref in current_weather.keys():
            preferences.append(pref)
        else:
            pass
    
    for preference in preferences:
        current_weather[str(preference)]'''
import calendar
from datetime import date, timedelta, datetime

today = date.today()
yesterday = today - timedelta(days=1)
tomorrow = today + timedelta(days=2)


print("Yesterday = ", calendar.day_name[yesterday.weekday()], yesterday.strftime('%d-%m-%Y'))
print("Today = ", calendar.day_name[today.weekday()], today.strftime('%d-%m-%Y'))
print("Tomorrow = ", calendar.day_name[tomorrow.weekday()], tomorrow.strftime('%d-%m-%Y'))
now = datetime.now()

current_time = now.strftime("%H:%M:%S")
one_hour = now + timedelta(hours=1)
print("Current Time =", current_time)
print(one_hour)


