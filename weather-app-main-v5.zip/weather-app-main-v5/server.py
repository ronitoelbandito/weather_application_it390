from flask import Flask, render_template, request
from weather import get_current_weather
from waitress import serve
from gpt import get_gpt_text
from datetime import date, timedelta, datetime
import calendar
import json
import gpt
from database.account import create_user, get_user_info
from database.emailLoop import emailLoop

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/weather', methods=['POST', 'GET'])
def get_weather():
    if request.method=='POST':

        #Get Create Account information from index.html
        username = request.form.get('username', '')
        email = request.form.get('email', '')
        userZip = request.form.get('userZip', '')
        tempPref = request.form.get('tempPref', 'N')
        precipitationPref = request.form.get('precipPref', 'N')
        windPref = request.form.get('windPref', 'N')
        uvPref = request.form.get('uvPref', 'N')
        humidityPref = request.form.get('humidityPref', 'N')

        #Original Zipcode variable
        zipcode = request.form['zipcode']
        templateFront = gpt.userTemplateFront
        templateBack = gpt.userTemplateBack
        userMode=False

        #Create User txt.file if info is not Null
        if ((username != '') and (tempPref != '')):
            create_user(username, email, userZip, tempPref, precipitationPref, windPref, uvPref, humidityPref)
        
        #If value is a username, unpack user values and grab user zipcode
        if not zipcode.isdigit() and zipcode != '':
            u_name,u_email,u_zipcode,u_temp_pref,u_precip_pref,u_windspeed_pref,u_uv_pref,u_humidity_pref = get_user_info(zipcode)
            

            #TEMP PREF
            if u_temp_pref == 'Y':
                templateFront=templateFront+'Temperature, '
            else:
                templateBack=templateBack+'Temperature, '
            #PRECIP PREF
            if u_precip_pref == 'Y':
                templateFront=templateFront+'Precipitation, '
            else:
                templateBack=templateBack+'Precipitation, '
            #WIND SPEED PREF
            if u_windspeed_pref == 'Y':
                templateFront=templateFront+'Wind Speed, '
            else:
                templateBack=templateBack+'Wind Speed, '
            #UV PREF
            if u_uv_pref == 'Y':
                templateFront=templateFront+'UV Index, '
            else:
                templateBack=templateBack+'UV Index, '
            #HUMIDITY PREF
            if u_humidity_pref == 'Y':
                templateFront=templateFront+'Humidity, '
            else:
                templateBack=templateBack+'Humidity, '
                      
            userMode=True          
            zipcode=u_zipcode
            
        #If zipcode is null, user zip is used
        if zipcode == '':
            zipcode = userZip        
            
        weather_data, city, alert_headline = get_current_weather(zipcode)

        #GPT Process
        json_string=json.dumps(weather_data)
        if userMode:
            print(templateFront+templateBack+". Here is the JSON Data: ")
            message = get_gpt_text(templateFront+templateBack+". Here is the JSON Data: "+json_string)
        else:
            message = get_gpt_text(gpt.template+json_string)


        today = date.today()
        day_one = today + timedelta(days=1)
        day_two = today + timedelta(days=2)
        day_three = today + timedelta(days=3)
        day_four = today + timedelta(days=4)
        day_five = today + timedelta(days=5)
        day_six = today + timedelta(days=6)
        day_seven = today + timedelta(days=7)
        now = datetime.now()
        
        one_hour = now + timedelta(hours=1)
        two_hours = now + timedelta(hours=2)
        three_hours = now + timedelta(hours=3)
        four_hours = now + timedelta(hours=4)
        five_hours = now + timedelta(hours=5)
        six_hours = now + timedelta(hours=6)
        seven_hours = now + timedelta(hours=7)
        eight_hours = now + timedelta(hours=8)

        #TEMP EMAIL PRINTOUT
        print('EMAIL LIST: ')
        emailLoop()
 
        return render_template(
            "weather.html",
            
            status=weather_data['current']['weather'][0]['description'],
            temp=weather_data["current"]["temp"],
            feels_like=weather_data["current"]["feels_like"],
            humidity=weather_data['current']['humidity'],
            wind_speed = weather_data['current']['wind_speed'],
            air_pressure =weather_data['current']['pressure'],
            uv_index=weather_data['current']['uvi'],
            dew_point=weather_data['current']['dew_point'],
            location=city,
            
            day_one = calendar.day_name[day_one.weekday()],
            day_one_status=weather_data['daily'][1]['summary'],
            day_one_temp=weather_data['daily'][1]['temp']['day'],
            day_one_hum=weather_data['daily'][1]['humidity'],
            
            day_two = calendar.day_name[day_two.weekday()],
            day_two_status=weather_data['daily'][2]['summary'],
            day_two_temp=weather_data['daily'][2]['temp']['day'],
            day_two_hum=weather_data['daily'][2]['humidity'],

            day_three =calendar.day_name[day_three.weekday()],
            day_three_status = weather_data['daily'][3]['summary'],
            day_three_temp=weather_data['daily'][3]['temp']['day'],
            day_three_hum=weather_data['daily'][3]['humidity'],

            day_four =calendar.day_name[day_four.weekday()],
            day_four_status= weather_data['daily'][4]['summary'],
            day_four_temp=weather_data['daily'][4]['temp']['day'],
            day_four_hum=weather_data['daily'][4]['humidity'],
            
            day_five =calendar.day_name[day_five.weekday()],
            day_five_status= weather_data['daily'][5]['summary'],
            day_five_temp=weather_data['daily'][5]['temp']['day'],
            day_five_hum=weather_data['daily'][5]['humidity'],
            
            day_six = calendar.day_name[day_six.weekday()],
            day_six_status= weather_data['daily'][6]['summary'],
            day_six_temp=weather_data['daily'][6]['temp']['day'],
            day_six_hum=weather_data['daily'][6]['humidity'],
            
            day_seven = calendar.day_name[day_seven.weekday()],
            day_seven_status= weather_data['daily'][7]['summary'],
            day_seven_temp=weather_data['daily'][7]['temp']['day'],
            day_seven_hum=weather_data['daily'][7]['humidity'],
            
            one_hour = one_hour.strftime("%H"),
            one_hour_temp=weather_data['hourly'][1]['temp'],

            two_hours = two_hours.strftime("%H"),
            two_hours_temp=weather_data['hourly'][2]['temp'],

            three_hours = three_hours.strftime("%H"),
            three_hours_temp=weather_data['hourly'][3]['temp'],

            four_hours = four_hours.strftime("%H"),
            four_hours_temp=weather_data['hourly'][4]['temp'],

            five_hours = five_hours.strftime("%H"),
            five_hours_temp=weather_data['hourly'][5]['temp'],

            six_hours = six_hours.strftime("%H"),
            six_hours_temp=weather_data['hourly'][6]['temp'],

            seven_hours = seven_hours.strftime("%H"),
            seven_hours_temp=weather_data['hourly'][7]['temp'],

            eight_hours = eight_hours.strftime("%H"),
            eight_hours_temp=weather_data['hourly'][8]['temp'],
            
            alert=alert_headline,
            
            #Ryan vars
            message=message
        )
        
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)