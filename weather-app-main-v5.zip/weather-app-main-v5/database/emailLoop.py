import os

def emailLoop():    
    folder_path = 'database'  #Folder name
    #Iterate through all files in the folder and check for txt files
    for filename in os.listdir(folder_path):
        if filename.endswith('.txt'):  #.txt file check
            file_path = os.path.join(folder_path, filename)
            with open(file_path, 'r') as file:
                lines = file.readlines()
                if len(lines) >= 2:  #Ensure there are at least two lines in the file
                    email = lines[1].strip().split('=')[1]  #Get the email line, strip, split.
                    print(email)


