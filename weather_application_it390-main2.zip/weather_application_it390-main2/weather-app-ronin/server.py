from flask import Flask, render_template, request
from weather import get_current_weather
from waitress import serve
from gpt import get_gpt_text
from datetime import date, timedelta, datetime
import calendar
import json
import gpt

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/weather', methods=['POST', 'GET'])
def get_weather():
    if request.method=='POST':
        zipcode = request.form['zipcode']
        weather_data, city, alert_headline = get_current_weather(zipcode)

        #GPT Process
        json_string=json.dumps(weather_data)
        message = get_gpt_text(gpt.template+json_string)
        
        today = date.today()
        day_one = today + timedelta(days=1)
        day_two = today + timedelta(days=2)
        day_three = today + timedelta(days=3)
        day_four = today + timedelta(days=4)
        day_five = today + timedelta(days=5)
        day_six = today + timedelta(days=6)
        day_seven = today + timedelta(days=7)
        now = datetime.now()
        
        one_hour = now + timedelta(hours=1)
        two_hours = now + timedelta(hours=2)
        three_hours = now + timedelta(hours=3)
        four_hours = now + timedelta(hours=4)
        five_hours = now + timedelta(hours=5)
        six_hours = now + timedelta(hours=6)
        seven_hours = now + timedelta(hours=7)
        eight_hours = now + timedelta(hours=8)
 
        return render_template(
            "weather.html",
            
            status=weather_data['current']['weather'][0]['description'],
            temp=weather_data["current"]["temp"],
            feels_like=weather_data["current"]["feels_like"],
            humidity=weather_data['current']['humidity'],
            wind_speed = weather_data['current']['wind_speed'],
            air_pressure =weather_data['current']['pressure'],
            uv_index=weather_data['current']['uvi'],
            dew_point=weather_data['current']['dew_point'],
            location=city,
            
            day_one = calendar.day_name[day_one.weekday()],
            day_one_status=weather_data['daily'][1]['summary'],
            day_one_temp=weather_data['daily'][1]['temp']['day'],
            
            day_two = calendar.day_name[day_two.weekday()],
            day_two_status=weather_data['daily'][2]['summary'],
            day_two_temp=weather_data['daily'][2]['temp']['day'],
            
            day_three =calendar.day_name[day_three.weekday()],
            day_three_status = weather_data['daily'][3]['summary'],
            day_three_temp=weather_data['daily'][3]['temp']['day'],

            day_four =calendar.day_name[day_four.weekday()],
            day_four_status= weather_data['daily'][4]['summary'],
            day_four_temp=weather_data['daily'][4]['temp']['day'],
            
            day_five =calendar.day_name[day_five.weekday()],
            day_five_status= weather_data['daily'][5]['summary'],
            day_five_temp=weather_data['daily'][5]['temp']['day'],
            
            day_six = calendar.day_name[day_six.weekday()],
            day_six_status= weather_data['daily'][6]['summary'],
            day_six_temp=weather_data['daily'][6]['temp']['day'],
            
            day_seven = calendar.day_name[day_seven.weekday()],
            day_seven_status= weather_data['daily'][7]['summary'],
            day_seven_temp=weather_data['daily'][7]['temp']['day'],
            
            one_hour = one_hour.strftime("%H:%M:%S"),
            one_hour_temp=weather_data['hourly'][1]['temp'],

            two_hours = two_hours.strftime("%H:%M:%S"),
            two_hours_temp=weather_data['hourly'][2]['temp'],

            three_hours = three_hours.strftime("%H:%M:%S"),
            three_hours_temp=weather_data['hourly'][3]['temp'],

            four_hours = four_hours.strftime("%H:%M:%S"),
            four_hours_temp=weather_data['hourly'][4]['temp'],

            five_hours = five_hours.strftime("%H:%M:%S"),
            five_hours_temp=weather_data['hourly'][5]['temp'],

            six_hours = six_hours.strftime("%H:%M:%S"),
            six_hours_temp=weather_data['hourly'][6]['temp'],

            seven_hours = seven_hours.strftime("%H:%M:%S"),
            seven_hours_temp=weather_data['hourly'][7]['temp'],

            eight_hours = eight_hours.strftime("%H:%M:%S"),
            eight_hours_temp=weather_data['hourly'][8]['temp'],
            
            alert=alert_headline,
            
            #Ryan vars
            message=message
        )
        
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)