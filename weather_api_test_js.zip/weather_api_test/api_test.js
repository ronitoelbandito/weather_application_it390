// ACCESSING ALL THE HTML COMPONENTS REQUIRED TO PERFORM ACTIONS ON.
let button = document.querySelector('.button')
let cityInputValue = document.querySelector('.cityInputValue')
let countryInputValue = document.querySelector('.countryInputValue')
let stateInputValue = document.querySelector('.stateInputValue')
let nameVal = document.querySelector('.name');
let temp = document.querySelector('.temp');
let desc = document.querySelector('.desc');


// ADDING EVENT LISTENER TO SEARCH BUTTON  
button.addEventListener('click', function(){
  

    const result = fetch(`http://api.openweathermap.org/geo/1.0/direct?q=${cityInputValue.value},${stateInputValue.value},${countryInputValue.value}&appid=fd26fa538134212d09e503a62de141ac`, { method: 'get' })
      .then(response => response.json()) // pass the data as promise to next then block
      .then(data => {
        const lon = data[0].lon;
        const lat = data[0].lat;
          return fetch(`https://api.openweathermap.org/data/3.0/onecall?lat=${lat}&lon=${lon}&units=imperial&appid=fd26fa538134212d09e503a62de141ac`); // make a 2nd request and return a promise
        })
      .then(response => response.json())
      .catch(err => {
        console.error('Request failed', err)
      })
            // I'm using the result const to show that you can continue to extend the chain from the returned promise
    result.then(r => {
      displayWeather(r, cityInputValue.value);
    });
})

const displayWeather = (weatherApiResponse, cityValue) =>{
    temp.innerText = `${cityValue}`
    desc.innerText = `${weatherApiResponse.current.temp}`
}


// I'm using the result const to show that you can continue to extend the chain from the returned promise
result.then(r => {
  console.log(r.first_stage); // 2nd request result first_stage property
});